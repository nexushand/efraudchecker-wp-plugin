<?php
/*
Plugin Name: eFraudChecker
Description: Prevent fraud with eFraudChecker – analyze customer phone numbers for order history, courier usage, and returns.
Author: NexusHand
Author URI: https://nexushand.com
Plugin URI: https://eFraudChecker.com
Text Domain: efraudchecker
Version: 1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('EFRAUDCHECKER_VERSION', '1.0.0');
define('EFRAUDCHECKER_TEXT_DOMAIN' , 'efraudchecker');
define('EFRAUDCHECKER_PATH', plugin_dir_path(__FILE__));
define('EFRAUDCHECKER_URL', plugin_dir_url(__FILE__));
define('EFRAUDCHECKER_ASSETS_URL', EFRAUDCHECKER_URL . 'assets/');
define('EFRAUDCHECKER_FILE', __FILE__);
// loader
require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-loader.php';

// Initialize plugin
add_action('plugins_loaded', 'e_fraud_checker_init');
function e_fraud_checker_init()
{ 
    $loader = new E_Fraud_Checker_Loader();
    $loader->init();

}

 // Activation and deactivation hooks
 register_activation_hook(EFRAUDCHECKER_FILE,   'e_fraud_checker_activate');
 register_deactivation_hook(EFRAUDCHECKER_FILE, 'e_fraud_checker_deactivate');
 

  //e_fraud_checker_activate
  function e_fraud_checker_activate(){
     // load wp functions
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
  
   
    update_option('e_fraud_checker_order_column', '1');
    update_option('e_fraud_checker_order_view', '1');
    update_option('e_fraud_checker_fraud_percentage', '50');

 
}
//e_fraud_checker_deactivate
function e_fraud_checker_deactivate(){
    //clear all transients 
    global $wpdb;
    // delete all transients, transients name start with e_fraud_
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_e_fraud_%'");
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_e_fraud_%'");

 
}