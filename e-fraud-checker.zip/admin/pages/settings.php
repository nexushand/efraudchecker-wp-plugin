<div class="efc-container">
    <div class="efc-main-dashboard-widget">
        <!-- stylish greeting -->
        <div class="efc-greeting-container">
            <h2 class="efc-greeting">eFraudChecker settings </h2>
            <p class="efc-greeting-subtext <?php echo esc_attr($status_class); ?>"> Manage
                eFraudChecker Options
                (<span style="color:blue;cursor:pointer; text-decoration:underline;" -- id="clearfraudcache">Clear
                    cache</span>)</p>

        </div>

        <form method="post" action="options.php" style="padding: 10px;">
            <?php
                settings_fields('e_fraud_checker_settings_group');
                do_settings_sections('e-fraud-checker-settings');
                submit_button('Save Settings');
                ?>
        </form>
    </div>
</div>