<div class="efc-container">
    <!-- Activate License Key Form -->
    <div class="efc-main-dashboard-widget">
        <!-- stylish greetign -->
        <div class="efc-greeting-container">
            <h2 class="efc-greeting">Activate Your License</h2>
            <?php  
              if(isset($_SESSION['efc_license_error'])) {
                echo '<p class="efc-greeting-subtext expired-subtext">' . $_SESSION['efc_license_error'] . '</p>';
                unset($_SESSION['efc_license_error']);
              }?>

            <p class="efc-greeting-subtext">
                Please enter your license key to activate the service.
            </p>
        </div>

        <!-- Show a form to enter License Key -->
        <div class="efc-main-dashboard-action">
            <form action="" method="post" class="efc-form">
                <input type="text" name="license_key" placeholder="Enter Your License Key">
                <button class="efc-button efc-button-primary">Activate</button>
            </form>

            <p style="margin-top: 20px">
                Don't have a license key? <a href="https://www.efraudchecker.com/?utm_source=plugin&utm_medium=getLicense&utm_campaign=trial" target="_blank">Get a license
                    key</a>
            </p>
            <p style="margin-top: 5px">
                Call Us: <a href="tel:+8801317778578">+8801317 778 578</a>
            </p>
        </div>
    </div>
</div>



<div class="efc_package-wrapper">

    <?php 
     
    $datas = E_Fraud_Checker_API::get_available_packages();
    if ($datas['success']) {
        $packages = $datas['data']['plans'];
    
     
    
        foreach ($packages as $package) { 
            ?>
    <div class="efc_card">
        <h2><?php echo $package['title']; ?></h2>
        <h3><?php echo $package['subtitle']; ?></h3>
        <h4 class="efc_price"><?php echo $package['price']; ?></h4>
        <p class="efc_duration"><?php echo $package['duration']; ?></p>
        <ul class="efc_features">
            <?php foreach ($package['features'] as $feature) { ?>
            <li><?php echo $feature; ?></li>
            <?php } ?>
        </ul>
        <a href="<?php echo $package['buttonLink']; ?>" target="_blank" class="efc_btn-buy">
            <?php echo $package['buttonTitle']; ?>
        </a>
    </div>


    <?php 
        }
    }
    ?>



</div>