<?php 
$datas = E_Fraud_Checker_API::get_about_us();
if ($datas['success']) {
    $about_us = $datas['data'];
    ?>
    <div class="efc-about-us">
    <?php echo $about_us;?>
    </div>
    <?php 
}
?>

