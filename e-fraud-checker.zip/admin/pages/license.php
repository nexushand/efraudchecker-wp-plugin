<?php 

$subs = new E_Fraud_Checker_API();  
        $subs_data = $subs->validate_subscription();
        
        $subs = isset($subs_data['data']) ? $subs_data['data'] : [];
        
        $is_valid = isset($subs['status']) && isset($subs['name']) && $subs['status'] && $subs['name'];
        $user_name = isset($subs['name']) ?  $subs['name']  : wp_get_current_user()->display_name;

        $status = isset($subs['status']) ? $subs['status'] : 'invalid';
        $subs['status']  =  $status;
        $status_class = $subs['status'] . '-subtext';
        $subs['message'] = isset($subs['message']) ? $subs['message'] : '';



?>
<div class="efc-container">
    <!-- Activate License Key Form -->
    <div class="efc-main-dashboard-widget">
        <!-- stylish greeting -->
        <div class="efc-greeting-container">
            <h2 class="efc-greeting">Hello, <?php echo  esc_html($user_name) ;?> </h2>
            <p class="efc-greeting-subtext <?php echo esc_attr($status_class); ?>"> <?php echo $subs['message'];?> </p>
        </div>

        <div class="efc-main-dashboard-action">
            <form action="" class="efc-form" method="post">
                <input type="text" name="license_key" placeholder="***********************" disabled="">
                <button class="efc-button efc-button-danger">Deactivate</button>
                <input type="hidden" name="revoke_license_efc" value="1">
            </form>
            <p style="margin-top: 20px">
                Don't have a license key? <a href="https://www.efraudchecker.com/?utm_source=plugin&utm_medium=getLicense&utm_campaign=trial" target="_blank">Get a license
                    key</a>
            </p>
            <p style="margin-top: 5px">
                Call Us: <a href="tel:+8801317778578">+8801317 778 578</a>
            </p>
        </div>

    </div>
</div>