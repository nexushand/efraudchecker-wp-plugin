<!-- packges -->

<div class="efc_package-wrapper">

    <?php 
 
$datas = E_Fraud_Checker_API::get_available_packages();
if ($datas['success']) {
    $packages = $datas['data']['plans'];

 

    foreach ($packages as $package) { 
        ?>
    <div class="efc_card">
        <div class="efc_card_content">
        <div style="padding: 20px;">
        <h2><?php echo $package['title']; ?></h2>
        <h3><?php echo $package['subtitle']; ?></h3>
        <h4 class="efc_price"><?php echo $package['price']; ?></h4>
        <p class="efc_duration"><?php echo $package['duration']; ?></p>
        <ul class="efc_features">
            <?php foreach ($package['features'] as $feature) { ?>
            <li><?php echo $feature; ?></li>
            <?php } ?>
        </ul>
        </div>
        <div style="padding: 20px; background-color: #f0f0f1; display: flex; justify-content: center; align-items: center;">
        <a href="<?php echo $package['buttonLink']; ?>" target="_blank" class="efc_btn-buy">
            <?php echo $package['buttonTitle']; ?>
        </a>
        </div>
        </div>
    </div>

                
    <?php 
    }
}
?>



</div>