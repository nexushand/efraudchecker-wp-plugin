<?php
  

        // Check subscription status
        $subs = new E_Fraud_Checker_API();  
        $subs_data = $subs->validate_subscription();
        $subs = isset($subs_data['data']) ? $subs_data['data'] : [];
        
        $is_valid = isset($subs['status']) && isset($subs['name']) && $subs['status'] && $subs['name'];
        $user_name = isset($subs['name']) ?  $subs['name']  : wp_get_current_user()->display_name;

        if ($is_valid) {
            
       
        $status = isset($subs['status']) ? $subs['status'] : 'invalid';
        $subs['status']  =  $status;
        $status_class = $subs['status'] . '-subtext';

            echo '
    <!-- start custom style section here  -->
    <div class="efc-container">
        <!-- If user is subscribed and active -->
        <div class="efc-main-dashboard-widget">
            <!-- stylish greetign -->
            <div class="efc-greeting-container">
                <h2 class="efc-greeting">Hello, ' . esc_html($user_name) . '</h2>
                <p class="efc-greeting-subtext ' . esc_attr($status_class) . '"> ' . $subs['message'] . '</p>
            </div>

            <!-- Show a form to enter phone number -->
            <div class="efc-main-dashboard-action phone-number-action efc-form">
                    <input type="text" id="phone-number" name="phone_number" class="efc-form input" placeholder="Enter Phone Number">
                    <button id="check-fraud" class="efc-button efc-button-primary">Check</button>

            </div>
            <div style="display:none;" class="  msgArea"> </div>
 
            <div id="loader" style="display:none;">
    <img src="' . esc_url(EFRAUDCHECKER_ASSETS_URL . 'img/ripple.svg') . '"
         alt="' . esc_attr__('Loading...', EFRAUDCHECKER_TEXT_DOMAIN) . '"
         class="custom-loading-spinner">
</div> 
<div id="fraud-result" ></div>

    <div class="efc-dashboard-result-content-before">
        <div class="efc-main-dashboard-widget">
            <!-- // Name, subscription status, subscription start and end date -->
            <div class="efc-greeting-container efc-border">
                <h3 class="efc-greeting">Subscription Details</h3>
                <table class="efc-main-dashboard-widget-content-table">
                    <tr>
                        <td>Company</td>
                        <td>' . esc_html($user_name) . '</td>
                    </tr>
                    <tr>
                        <td>Subscription Status</td>
                        <td class="status  ' . esc_attr($status) . '">' . esc_html($status) . '</td>
</tr>
<tr>
    <td>Subscription Start Date</td>
    <td>
        ' . esc_html($subs['startDate']) . '
    </td>
</tr>
<tr>
    <td>Subscription End Date</td>
    <td>
        ' . esc_html($subs['endDate']) . '
    </td>
</tr>
</table>
</div>
</div>
</div>

</div>
</div>
<!-- end custom style section here  -->
';
} else {
echo '
<div class="efc-container">

    <!-- If user is not subscribed to eFraudChecker-->
    <div class="efc-main-dashboard-widget ">
        <!-- stylish greetign -->
        <div class="efc-greeting-container">
            <h5 class="efc-greeting">Hello, ' . esc_html($user_name) . ' !</h5>
            <p class="efc-greeting-subtext">
                You are not subscribed to eFraudChecker. Please enter your license key to activate
                the
                service.
            </p>
        </div>

        <!-- Show a button to Activate Your License -->
        <div class="efc-main-dashboard-action">
            <a href="admin.php?page=efraudchecker-activate">
                <button class="efc-button efc-button-primary">Activate Your License</button>
            </a>
        </div>

    </div>

</div>
';
}