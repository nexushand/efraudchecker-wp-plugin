 
<div class="wrap efc-admin-wrap">
    <h1><?php _e( 'eFraudChecker', 'efraudchecker' ); ?> </h1>
    <div class="notice notice-success ">
        <h1><?php _e( 'Welcome to eFraudChecker! ', 'efraudchecker' ); ?> <small>(v<?php echo EFRAUDCHECKER_VERSION; ?>)</small>
            </h1> 
    </div>
    <?php  do_action( 'efc_admin_notices_top' ); ?>
    <!-- messages -->
    <?php if ( isset( $_SESSION['efc_license_success'] ) ) : ?>
    <div id="message" class="updated notice is-dismissible">
        <p><?php echo $_SESSION['efc_license_success']; ?></p>
        <button type="button" class="notice-dismiss">
            <span class="screen-reader-text"><?php _e( 'Dismiss this notice.', 'efraudchecker' ); ?></span>
        </button>
    </div>
    <?php
unset(
    $_SESSION['efc_license_success']
);
endif; ?>
    
    <h2 class="nav-tab-wrapper efc-nav-tab-wrapper">
        <?php foreach ( $tabs as $tab_key => $tab_name ) : ?>
        <a href="?page=efraudchecker&tab=<?php echo $tab_key; ?>"
            class="nav-tab efc-nav-tab <?php echo $active_tab == $tab_key ? 'nav-tab-active' : ''; ?>"><?php echo $tab_name; ?></a>
        <?php endforeach; ?>
    </h2>
    <!-- body -->
    <div class="tab-content efc-admin-tab">
        <?php 
        do_action( 'efc_admin_notices' );
        
        $file = EFRAUDCHECKER_PATH . 'admin/pages/' . $active_tab . '.php';
        if ( file_exists( $file ) ) {
            include $file;
        }  
        do_action( 'efc_admin_tab_' . $active_tab );
        ?>

    </div>
</div>
<!-- wp admin setting page with tabs -->