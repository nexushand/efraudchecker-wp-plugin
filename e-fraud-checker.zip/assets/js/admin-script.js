jQuery(document).ready(function($) {
 

    // License activation button action
    $('#activate-license').on('click', function(e) {
        e.preventDefault();

        var licenseKey = $('#license-key').val();

        if (licenseKey === '') {
            alert('Please enter a license key.');
            return;
        }

        // Disable the button while activating
        $(this).attr('disabled', true);
        $('#license-status').html('<p>Activating license...</p>');

        // Make AJAX request to activate license
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'e_fraud_checker_activate_license', // License activation AJAX action
                license_key: licenseKey
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (data.success) {
                    $('#license-status').html('<p>License activated successfully!</p>');
                } else {
                    $('#license-status').html('<p>License activation failed: ' + data.message + '</p>');
                }
            },
            error: function(xhr, status, error) {
                $('#license-status').html('<p>An error occurred: ' + error + '</p>');
            },
            complete: function() {
                $('#activate-license').attr('disabled', false); // Re-enable button after request
            }
        });
    });
    

});
