jQuery(document).ready(function ($) {
    $('.fraud-checker-btn').on('click', function (e) {
        e.preventDefault();
        var btn = $(this);
        var phone = $(this).data('phone');
        
        var orderId = $(this).data('order-id');
        var resultSection = $('#efc-frad-checker-result-'+  orderId);

        var progressBar = $('#progress-bar-' + orderId);
        var progress = progressBar.find('.efc-progress-order');
        var loadingText = progressBar.find('.loading-text');

        // Show the progress bar and reset its state
        progressBar.show();
        progress.css('width', '0%');
        loadingText.text('Loading...');
        let ajaxurl = efc_ajax_object.ajax_url;


        // Perform the AJAX request
        $.ajax({
            url: ajaxurl, // WordPress AJAX URL
            type: 'POST',
            data: {
                action: 'check_fraud',
                phone: phone,
                order_id: orderId,
                // _wpnonce: efraudchecker.nonce // Use nonce for security
            },
            beforeSend: function () {
                btn.text('Checking...');
            },
            success: function (response) {
                
                console.log(response);
                btn.fadeOut();
                resultSection.html(response);
                resultSection.fadeIn();
                 
            },
            error: function () {
                // Handle error 
                btn.text('Error');
            }
        });
    });
    // clearfraudcache
    $('#clearfraudcache').click(function (e) {
        e.preventDefault();
        var btn = $(this);
        let ajax_url = efc_ajax_object.ajax_url;
        $.ajax ({
            url: ajax_url,
            type: 'POST',
            data: {
                action: 'e_fraud_checker_clear_cache'
            },
            beforeSend: function () {
                btn.text('Clearing...');
            },
            success: function (response) {
                btn.text('Clear Cache');
                alert('Cache Cleared');
            },
            error: function () {
                btn.text('Error');
            }
        });
    });
    function isPhoneNumber(phone) {
        return phone.match(/^\d{10}$/);
    }

    jQuery('#check-fraud').on('click', function(e) {

        e.preventDefault();
        var phoneNumber = jQuery('#phone-number').val();
        $('.msgArea').fadeOut(); 
        if (phoneNumber == ''
            || phoneNumber.length < 10 ||
            isPhoneNumber(phoneNumber) == false
        ) { 
    
            $('.msgArea').html('<div class="efc-alert efc-alert-danger" role="alert">Please enter a valid phone number.</div>');
            $('.msgArea').fadeIn();
            setTimeout(function() {
                $('.msgArea').fadeOut();    
            }, 3000);
    
            return;
        }
    
     
        let ajaxurl = efc_ajax_object.ajax_url;
    
        // Show the loader when the request starts
        jQuery('#loader').show();
        jQuery('#fraud-result').html(''); // Clear previous result if any
    
        // Make the AJAX request
        jQuery.post(ajaxurl, {
            action: 'e_fraud_checker_fraud_check',
            phone_number: phoneNumber
        }, function(response) {
            // Hide the loader once the request is complete
            jQuery('#loader').hide();
    
            // Show the response in the result area
            jQuery('#fraud-result').html(response);
        }).fail(function() {
            // Hide the loader in case of failure and show an error
            jQuery('#loader').hide();
            jQuery('#fraud-result').html('Error occurred while fetching data.');
        });
    });
    
});

