<?php 
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class E_Fraud_Checker_Loader{
    function __construct(){
        
    } 

      //hooks
    function run(){
      // plugin links
        add_filter('plugin_action_links_' . plugin_basename(EFRAUDCHECKER_FILE), [$this, 'e_fraud_checker_plugin_links']);
        // after version links
        add_filter('plugin_row_meta', [$this, 'e_fraud_checker_plugin_row_meta'], 10, 2);

    }
    //e_fraud_checker_plugin_row_meta
    function e_fraud_checker_plugin_row_meta($links, $file){
        if (plugin_basename(EFRAUDCHECKER_FILE) === $file) {
            $row_meta = [
                'docs' => '<a href="https://www.youtube.com/watch?v=6tWbltv8J9E&list=PLr4XcyJ-YnrKk9d52sOWKB5vFObLFI-S1" target="_blank">Docs</a>',
                'support' => '<a href="https://wa.me/+8801317778578?text=Hello,%20I%27m%20from%20eFraudChecker%20WordPress%20Plugin.%20I%20need%20help%20with%20my%20order.%20I%20am%20interested%20in%20your%20tools." target="_blank">Support</a>',
            ];
            return array_merge($links, $row_meta);
        }
        return (array) $links;
    }
    //e_fraud_checker_plugin_links
    function e_fraud_checker_plugin_links($links){
        $links[] = '<a href="' . admin_url('admin.php?page=efraudchecker&tab=settings') . '">Settings</a>';
        return $links;
    }
    
    
    // dependencies
    function load_dependencies(){
        // Include required files
        require_once EFRAUDCHECKER_PATH . 'includes/e-fraud-checker-db.php';
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-settings.php'; 
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-api.php';
        require_once EFRAUDCHECKER_PATH . 'includes/class-efraudchecker-dashboard-notice.php';
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-subscription.php';
        //admin
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-admin.php';
        //ajax 
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-ajax.php';
        //dashboard
        require_once EFRAUDCHECKER_PATH . 'includes/class-e-fraud-checker-dashboard.php';
        

        // helper func.
        require_once EFRAUDCHECKER_PATH . 'includes/helpers.php';


    }
    // init 
    function init(){
        $this->load_dependencies();
        new E_Fraud_Checker_Settings();
        new E_Fraud_Checker_Dashboard_Notice();
        new E_Fraud_Checker_Subscription();
        new E_Fraud_Checker_Admin();
        new E_Fraud_Checker_Ajax();
        new E_Fraud_Checker_Dashboard();
        
        $this->run();
    }

}