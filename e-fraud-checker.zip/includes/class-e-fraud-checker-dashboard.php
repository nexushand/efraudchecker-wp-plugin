<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
class  E_Fraud_Checker_Dashboard
{
    function __construct()
    {
         // order table column    
         add_filter('manage_edit-shop_order_columns', [$this, 'add_order_column']);
         //manage_woocommerce_page_wc-orders_columns
         add_filter('manage_woocommerce_page_wc-orders_columns', [$this, 'add_order_column']);
 
         add_action('manage_shop_order_posts_custom_column', [$this, 'add_order_column_content'], 10, 2);
         //manage_woocommerce_page_wc-orders_custom_column
         add_action('manage_woocommerce_page_wc-orders_custom_column', [$this, 'add_order_column_content'], 10, 2);

    }
    
    //add_order_column
    public function add_order_column($columns)
    {
        $show = get_option('e_fraud_checker_order_column', false);
        if (!$show || !efc_is_active() || (efc_is_active() &&
            !get_option('e_fraud_checker_order_column', false)
        )) {
            return $columns;
        }

        $columns['fraud_checker'] = 'Fraud Checker';
        return $columns;
    }
    //add_order_column_content
   public function add_order_column_content($column, $order = null){
    global $post;

   
    if (!is_object($order)) {
        $order = new WC_Order($post->ID);
    }

    if ($column == 'fraud_checker') {

        $show = get_option('e_fraud_checker_order_column', false);
        if (!$show || !efc_is_active() || (efc_is_active() &&
            !get_option('e_fraud_checker_order_column', false)
        )) {
            return;
        }
        if (e_fraud_subs_checker_status() != 'active') {
            echo 'Your efraudchecker Subscription status is ' . e_fraud_subs_checker_status();
            return;
        }
        
        $phone_number = $order->get_billing_phone();
        // $secure_data = $order
        $phone_number = str_replace('+880', '0', $phone_number); // remove +880



        echo '<button type="button" class="fraud-checker-btn" data-phone="' . esc_attr($phone_number) . '" data-order-id="' . esc_attr($order->get_id()) . '">Check Fraud</button>';
        echo '<div style="display:none"  class="efc-frad-checker-result" id="efc-frad-checker-result-' . esc_attr($order->get_id()) . '"></div>';
          return;
        
         

        $phone_number = $order->get_billing_phone();
        // $secure_data = $order
        $phone_number = str_replace('+880', '0', $phone_number); // remove +880

        if ($phone_number) {
            $apiCheck = new E_Fraud_Checker_API();
            $data = $apiCheck->check_fraud_by_phone($phone_number, $order);

            if ($data['success']) {
                $totalOrders = isset($data['data']['total']['total']) ? $data['data']['total']['total'] : 0;
                $successOrders = isset($data['data']['total']['success']) ? $data['data']['total']['success'] : 0;
                $failedOrders = isset($data['data']['total']['failed']) ? $data['data']['total']['failed'] : 0;
                $successRate = isset($data['data']['total']['successRate']) ? $data['data']['total']['successRate'] : 0;

                $classSc = efc_is_fraud_by_rate($successRate) ? 'efc-progress-success' : 'efc-progress-danger';
                if($totalOrders <= 0){
                    $classSc = 'efc-progress-success';
                }
                // UI work with the response
                echo '<span class="efc-fraud-checker-success ">' . $successRate . '%</span>';

                // Progress bar with tooltip on hover
                echo '<div class="efc-progress-bar">
                        <div class="efc-progress ' . $classSc . '" style="width: ' . $successRate . '%;"></div>
                        <div class="tooltip">
                            Success Rate: ' . $successRate . '%<br>
                            Total Orders: ' . $totalOrders . '<br>
                            Success: ' . $successOrders . '<br>
                            Failed: ' . $failedOrders . '
                        </div>
                      </div>';
            } else {
                //response msg 
                $efc_msg = isset($data['message']) ? $data['message'] : 'Phone number not supported';
                echo '<span class="efc-fraud-checker-fail">' . $efc_msg . '</span>';
            }
        } else {
            echo 'No phone number';
        }
    }
}




}