<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class E_Fraud_Checker_Admin
{
    public function __construct()
    { 
        // admin enqueue scripts
        add_action('admin_enqueue_scripts', [$this, 'admin_enqueue_scripts']);
       
        add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'order_view']);
        // order placed
        add_action('woocommerce_checkout_order_processed', [$this, 'order_placed']);

    }
    //order_placed
    //call api for send data
    
    function order_placed_2($details_id){
        $details = wc_get_order($details_id);
        $phone_number = $details->get_billing_phone();
        //data  
        $details_data = $details->get_data();        
        // send to api
        $apiCheck = new E_Fraud_Checker_API();
        $data =[
            'phone' => $phone_number,            
            'details' => $details_data,
        ];

        $dataStatus = $apiCheck->send_order_data($data);
        
    }
    //order_placed
    function order_placed($order_id){
        $order = wc_get_order($order_id);
        
        $phone_number = $order->get_billing_phone();
        
        //data  
        $details_data = $order->get_data();        
        // send to api
        $apiCheck = new E_Fraud_Checker_API();
        $data =[
            'phone' => $phone_number,            
            'details' => $details_data,
        ];
 
        $dataStatus = $apiCheck->send_order_data($data);   
        

    }


    //order_view
    public function order_view($order)
    {
        $show = get_option('e_fraud_checker_order_view', false);
        if (!$show || !efc_is_active() || (efc_is_active() &&
            !get_option('e_fraud_checker_order_view', false)
        )) {
            return;
        }
        if (e_fraud_subs_checker_status() != 'active') {
            echo 'Your efraudchecker Subscription status is ' . e_fraud_subs_checker_status();
            return;
        }

        $phone_number = $order->get_billing_phone();

        $phone_number = str_replace('+880', '0', $phone_number);

        $apiCheck = new E_Fraud_Checker_API();
        $phone_number = $order->get_billing_phone();
        
        //data  
        $details_data = $order->get_data();        
        // send to api
        $apiCheck = new E_Fraud_Checker_API();
        $dataS =[
            'phone' => $phone_number,            
            'details' => $details_data,
        ];
         
        $data = $apiCheck->send_order_data($dataS);


        // $data = $apiCheck->check_fraud_by_phone($phone_number);
        if ($data['success']) {
            include EFRAUDCHECKER_PATH . 'templates/order_meta_view.php';
        } else {
            $efc_message = isset($data['message']) ? $data['message'] : 'Phone number not supported';
            echo '<div class="efc-container2"><span class="efc-fraud-checker-fail" style="margin-top: 10px">' . $efc_message . '</span> </div>';
        }

    }

    //enqueue_scripts
    public function admin_enqueue_scripts()
    {
        wp_enqueue_style('efraudchecker-style', EFRAUDCHECKER_ASSETS_URL . 'css/admin-style.css');
        
        wp_enqueue_style('efraudchecker-admin-css', EFRAUDCHECKER_ASSETS_URL . 'css/admin/style.css', [], EFRAUDCHECKER_VERSION);
        wp_enqueue_script('efraudchecker-admin-js', EFRAUDCHECKER_ASSETS_URL . 'js/admin.js', ['jquery'], EFRAUDCHECKER_VERSION, true);
      
        wp_localize_script('efraudchecker-admin-js', 'efc_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
        wp_enqueue_script('efraudchecker-order-js', EFRAUDCHECKER_ASSETS_URL . 'js/efc-order-column.js', ['jquery'], EFRAUDCHECKER_VERSION, true);
    }
    
}