<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class E_Fraud_Checker_Subscription
{

    private $api_key;
    // old key
    private $old_api_key;
    // is active
    private $is_active;

    private $domain;
    private static $instance = null;


    public function __construct()
    {

        $this->api_key = get_option('e_fraud_checker_api_key'); // Get API key from WordPress options
        $this->domain = get_site_url(); // Get current domain
        //e_fraud_checker_old_api_key
        $this->old_api_key = get_option('e_fraud_checker_old_api_key', '');
        $this->is_active = get_option('e_fraud_checker_is_active', false);

    }
    // instance
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    //is valid_api
    public static function is_valid_api(): bool
    { 
        return (new self())->is_subscription_valid();

    } 

    // Check if the subscription is valid by making an API call
    public function is_subscription_valid()
    {
        if (!$this->api_key) {
            return false;
        }
        // transient
        $is_valid = get_transient('e_fraud_checker_is_valid');

        // is active then check both
        if( $this->is_active && ($this->api_key == $this->old_api_key) && $is_valid){  
            return true;
        }


        $response = wp_remote_post('https://server.efraudchecker.com/api/v1/shield/check-subscription', [
            'body' => json_encode([
                'apiKey' => $this->api_key,
                'domain' => $this->domain,
            ]),
            'headers' => ['Content-Type' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        if (isset($result['success']) && $result['success']) {
            set_transient('e_fraud_checker_is_valid', true, 60 * 60 * 24); // Cache for 24 hours
            update_option('e_fraud_checker_old_api_key', $this->api_key);
            update_option('e_fraud_checker_is_active', true);
            return true;
        }else{
            // revoke
            update_option('e_fraud_checker_is_active', false);
            delete_transient('e_fraud_checker_is_valid');

            // var_dump(
            //     $result
            // );
        }
        return false;
    }
    public function get_subscription_data()
    {
        if (!$this->api_key) {
            return false;
        }

        $response = wp_remote_post('https://server.efraudchecker.com/api/v1/shield/check-subscription', [
            'body' => json_encode([
                'apiKey' => $this->api_key,
                'domain' => $this->domain,
            ]),
            'headers' => ['Content-Type' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);

        return isset($result['data']) ? $result['data'] : false;
    }

    // Get validity days left
    public function get_validity_days()
    {
        if (!$this->api_key) {
            return 'Invalid API Key';
        }

        $response = wp_remote_post('https://server.efraudchecker.com/api/v1/shield/check-subscription', [
            'body' => json_encode([
                'apiKey' => $this->api_key,
                'domain' => $this->domain,
            ]),
            'headers' => ['Content-Type' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return 'Unable to fetch subscription status';
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);

        if (isset($result['success']) && $result['success']) {
            return $result['data']['remainingDays']; // Assuming API returns 'validity_days'
        }

        return 'No valid subscription found';
    }

    // Get fraud data for a phone number
    public function get_fraud_data_by_phone($phone_number)
    {
        $cached_data = get_transient('e_fraud_checker_fraud_data_' . $phone_number);
        if ($cached_data) {
            return ['success' => true, 'data' => $cached_data];
        }

        $timestamp = gmdate('c'); // Same as JS's new Date().toISOString()
    $signature = efc_generate_signature($timestamp);

    $headers = [
        'Content-Type' => 'application/json',
        'x-signature' => $signature,
        'x-timestamp' => $timestamp,
        'x-client' => 'wordpress',
        'x-version' => '3.0'
    ];

        
        $response = wp_remote_post('https://server.efraudchecker.com/api/v1/shield/fraud-checker', [
            'body' => json_encode([
                'phone' => $phone_number,
                'domain' => $this->domain,
                'apiKey' => $this->api_key,
                'medium' => 'plugin',
            ]),
            'headers' => $headers,
            'timeout' => 30, // Set a timeout for the request
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'message' => 'API request failed'];
        }

        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        if (isset($result['success']) && $result['success']) {
            set_transient('e_fraud_checker_fraud_data_' . $phone_number, $result['data'], 60 * 60 * 24); // Cache for 24 hours
        }

        return $result;
    }
}