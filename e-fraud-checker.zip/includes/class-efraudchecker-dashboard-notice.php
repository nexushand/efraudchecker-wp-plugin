<?php

class E_Fraud_Checker_Dashboard_Notice
{
    private $subscription;

    public function __construct()
    {
        $this->subscription = new E_Fraud_Checker_Subscription();
        add_action('wp_dashboard_setup', [$this, 'add_dashboard_notice']);
    }

    public function add_dashboard_notice()
    {
        add_meta_box(
            'efc_dashboard_notice', // Meta box ID
            'eFraudChecker Subscription', // Title of the meta box
            [$this, 'render_dashboard_notice'], // Callback function to display content
            'dashboard', // Where to display (dashboard in this case)
            'normal', // Context (normal will place it after the dashboard title)
            'high' // Priority (high ensures it appears in the desired location)
        );
    }

   public function render_dashboard_notice()
{
    // Get subscription data
    $subs = $this->subscription->get_subscription_data();

    // Check if $subs is an array and contains the expected keys
    if (is_array($subs) && isset($subs['status'], $subs['name'])) {
        $is_valid = $subs['status'] && $subs['name'];
        $user_name = $subs['name'] ?: wp_get_current_user()->display_name;
        $status = $subs['status'];
        $status_class = $subs['status'] . '-subtext';

        if ($is_valid) {
            echo '<div class="efc-main-dashboard-widget" style="margin:0px !important;">
                        <div class="efc-greeting-container">
                            <h5 class="efc-greeting">Hello, ' . esc_html($user_name) . '</h5>
                            <p class="efc-greeting-subtext ' . esc_attr($status_class) . '"> ' . $subs['message'] . '</p>
                        </div>
                       
                        <div class="efc-main-dashboard-widget-content">
                            <div class="efc-main-dashboard-widget-content-heading">
                                Subscription Details
                            </div>
                            <table class="efc-main-dashboard-widget-content-table">
                                <tr>
                                    <td>Company</td>
                                    <td>' . esc_html($user_name) . '</td>
                                </tr>
                                <tr>
                                    <td>Subscription Status</td>
                                    <td class="status ' . esc_attr($status) . '" style="text-transform: capitalize;">' . esc_html($status) . '</td>
                                </tr>
                                <tr>
                                    <td>Subscription Start Date</td>
                                    <td>' . esc_html($subs['startDate']) . '</td>
                                </tr>
                                <tr>
                                    <td>Subscription End Date</td>
                                    <td>' . esc_html($subs['endDate']) . '</td>
                                </tr>
                            </table>
                        </div>
                  </div>';
        } else {
            echo '<div class="efc-main-dashboard-widget" style="margin:0px !important;">
                        <div class="efc-greeting-container">
                            <h5 class="efc-greeting">Hello, ' . esc_html($user_name) . '</h5>
                            <p class="efc-greeting-subtext">
                                You are not subscribed to eFraudChecker. Please enter your
                                license key to activate the service.
                            </p>
                        </div>
                        <div class="efc-main-dashboard-action">
                        <a href="admin.php?page=efraudchecker-activate">
                            <button class="efc-button efc-button-primary">Activate Your License</button>
                        </a>
                        </div>
                  </div>';
        }
    } else {
        // Handle the case when $subs is not a valid array
        $user_name = wp_get_current_user()->display_name;
        echo '<div class="efc-main-dashboard-widget" style="margin:0px !important;">
                    <div class="efc-greeting-container">
                        <h5 class="efc-greeting">Hello, ' . esc_html($user_name) . '</h5>
                        <p class="efc-greeting-subtext">
                            You are not subscribed to eFraudChecker. Please enter your
                                license key to activate the service.
                        </p>
                    </div>
                    <div class="efc-main-dashboard-action">
                    <a href="admin.php?page=efraudchecker-activate">
                        <button class="efc-button efc-button-primary">Activate Your License</button>
                    </a>
                    </div>
              </div>';
    }
}


}