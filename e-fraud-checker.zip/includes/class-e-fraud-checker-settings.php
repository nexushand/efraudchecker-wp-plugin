<?php
class E_Fraud_Checker_Settings { 
    public function __construct() { 
        add_action('admin_menu', array($this, 'add_menu'));

        add_action('admin_init', [$this, 'register_settings']);
    }
    
    //admin_menu
    public function add_menu()
    {
        add_menu_page('eFraudChecker', 'eFraudChecker', 'manage_options', 'efraudchecker', array($this, 'layout'), 'dashicons-shield', 20);
        if (efc_is_active()) {
            //submenus
            add_submenu_page('efraudchecker', 'Dashboard', 'Dashboard', 'manage_options', 'efraudchecker', array($this, 'layout'));
            add_submenu_page('efraudchecker', 'Settings', 'Settings', 'manage_options', 'efraudchecker-settings', array($this, 'layout'));
            //packages

        } else {
            add_submenu_page('efraudchecker', 'Activate', 'Activate', 'manage_options', 'efraudchecker-activate', array($this, 'layout'));
        }

        add_submenu_page('efraudchecker', 'Packages', 'Packages', 'manage_options', 'efraudchecker-packages', array($this, 'layout'));

    }

    public function register_settings()
    {
        // session start
        if (!session_id()) {
            session_start();
        }

        register_setting('e_fraud_checker_settings_group', 'e_fraud_checker_api_key');
 
        // section on order view/ table
        add_settings_section(
            'e_fraud_checker_order_settings_section',
            '',
            null,
            'e-fraud-checker-settings'
        );
        // table column show/hide
        add_settings_field(
            'e_fraud_checker_order_column_field',
            'Show on order table',
            [$this, 'render_order_column_field'],
            'e-fraud-checker-settings',
            'e_fraud_checker_order_settings_section'
        );
        // order view show/hide
        add_settings_field(
            'e_fraud_checker_order_view_field',
            'Show on order details',
            [$this, 'render_order_view_field'],
            'e-fraud-checker-settings',
            'e_fraud_checker_order_settings_section'
        );
        // fraud percentage
        add_settings_field(
            'e_fraud_checker_fraud_percentage_field',
            'Fraud Percentage',
            [$this, 'render_fraud_percentage_field'],
            'e-fraud-checker-settings',
            'e_fraud_checker_order_settings_section'
        );

        // redirect if not activated for protected tabs
        if (!efc_is_active()
            && isset($_GET['page'])
            &&
            (
                in_array($_GET['page'], ['efraudchecker-settings'])
                || (isset($_GET['tab']) && in_array($_GET['tab'], ['settings', 'dashboard']))
            )) {
            wp_redirect(admin_url('admin.php?page=efraudchecker-activate'));
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST'
            && (isset($_POST['option_page']) && $_POST['option_page'] == 'e_fraud_checker_settings_group')

        ) {
            // save settings
            update_option('e_fraud_checker_order_column', isset($_POST['e_fraud_checker_order_column']) ? 1 : 0);
            update_option('e_fraud_checker_order_view', isset($_POST['e_fraud_checker_order_view']) ? 1 : 0);
            update_option('e_fraud_checker_fraud_percentage', isset($_POST['e_fraud_checker_fraud_percentage']) ? $_POST['e_fraud_checker_fraud_percentage'] : 50);

            // success msg wp
            $_SESSION['efc_license_success'] = 'Settings saved';
            wp_redirect(admin_url('admin.php?page=efraudchecker-settings'));
            exit;
        }

        // license checker
        if (isset($_GET['page']) && (
            in_array($_GET['page'], ['efraudchecker-activate', 'efraudchecker', 'efraudchecker-about'])
            || (isset($_GET['tab']) && in_array($_GET['tab'], ['activate', 'packages', 'about']))
        ) && isset($_POST['license_key'])
            && !empty($_POST['license_key'])
        ) {
            // verify license key
            $license_key = sanitize_text_field($_POST['license_key']);

            update_option('e_fraud_checker_api_key', $license_key);

            $api = new E_Fraud_Checker_API();
            $response = $api->validate_subscription(true);

            if ($response['success']) {

                update_option('e_fraud_checker_old_api_key', $license_key);
                update_option('e_fraud_checker_is_active', true);

                // redirect to dashboard
                // success msg wp
                $_SESSION['efc_license_success'] = 'License key verified';
                wp_redirect(admin_url('admin.php?page=efraudchecker'));
                exit;
            } else {
                //  error wp
                $_SESSION['efc_license_error'] = $response['message'];
                wp_redirect(admin_url('admin.php?page=efraudchecker'));
                exit;
            }

        }
        // revoke licence
        if (
            $_SERVER['REQUEST_METHOD'] == 'POST'
            &&
            isset($_POST['revoke_license_efc'])) {
            efc_revoke_subscription();
            $_SESSION['efc_license_success'] = 'License key revoked';
            wp_redirect(admin_url('admin.php?page=efraudchecker'));
            exit;
        }

    }
    
    //register_settings 
    //render_fraud_percentage_field
    public function render_fraud_percentage_field()
    {
        $fraud_percentage = get_option('e_fraud_checker_fraud_percentage', 50);
        ?>
<input type="number" name="e_fraud_checker_fraud_percentage" value="<?php echo
        esc_attr($fraud_percentage); ?>" class="regular-text">
<?php
}

    //render_order_column_field
    public function render_order_column_field()
    {
        $order_column = get_option('e_fraud_checker_order_column');

        ?>
<input type="checkbox" name="e_fraud_checker_order_column" value="1" <?php checked($order_column, 1);?>>
<?php
}
    //render_order_view_field
    public function render_order_view_field()
    {
        $order_view = get_option('e_fraud_checker_order_view');
        ?>
<input type="checkbox" name="e_fraud_checker_order_view" value="1" <?php checked($order_view, 1);?>>
<?php
}

    //render_api_key_field
    public function render_api_key_field()
    {
        $api_key = get_option('e_fraud_checker_api_key');
        ?>
<input type="text" name="e_fraud_checker_api_key" value="<?php echo
        esc_attr($api_key); ?>" class="regular-text">
<?php
}

    //layout
    public function layout()
    {
        $default_tab = 'dashboard';
        $tabs = array(
            'dashboard' => 'Dashboard',
            'settings' => 'Settings',
            'packages' => 'Packages',
            'license' => 'License',
            'about' => 'About',
        );
        if (!efc_is_active()) {
            // $tabs['activate'] = 'Activate';
            // append to top
            $tabs = array('activate' => 'Activate') + $tabs;

            $default_tab = 'activate';
            unset($tabs['dashboard']);
            unset($tabs['settings']);
            unset($tabs['license']);
        }
        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
        $slug = isset($_GET['page']) ? $_GET['page'] : 'efraudchecker';
        if (!isset($_GET['tab']) || $_GET['tab'] == '') {

            switch ($slug) {
                case 'efraudchecker':
                    // $active_tab = 'dashboard';
                    break;
                case 'efraudchecker-settings':
                    $active_tab = 'settings';
                    break;
                case 'efraudchecker-packages':
                    $active_tab = 'packages';
                    break;
                case 'efraudchecker-about':
                    $active_tab = 'about';
                    break;
                case 'efraudchecker-activate':
                    $active_tab = 'activate';
                    break;

            }
        }

        include EFRAUDCHECKER_PATH . 'admin/layout.php';
    }



 
}