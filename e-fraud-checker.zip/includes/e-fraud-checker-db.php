<?php
class E_Fraud_Checker_DB {
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'e_fraud_checker';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            phone_number varchar(20) NOT NULL,
            fraud_status text NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
      

    }
}