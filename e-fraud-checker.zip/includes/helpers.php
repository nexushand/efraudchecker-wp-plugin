<?php 

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
//e_fraud_checker_get_subscription_status
function e_fraud_checker_get_subscription_status()
{
    $subs = new E_Fraud_Checker_API();
    $subs_data = $subs->get_subscription_data();
    return $subs_data;
}

// is efc_active
function efc_is_active(): bool
{
    return E_Fraud_Checker_Subscription::is_valid_api();
}
// revoke subscription
function efc_revoke_subscription()
{
    update_option('e_fraud_checker_api_key', '');
    update_option('e_fraud_checker_old_api_key', '');
    update_option('e_fraud_checker_is_active', false);
    delete_option('e_fraud_checker_subscription_data');
    
}
// is fraud by rate
function efc_is_fraud_by_rate($successRate, $total = null): bool
{ 
    $rate =  get_option('e_fraud_checker_fraud_percentage', 50);
    $rate  = (int) $rate;
    return ( $successRate >= $rate);
}
// Hook into WooCommerce's Edit Order page
// add_action('woocommerce_admin_order_data_after_order_details', 'show_fraudchecker_in_order_edit_page');
 
//e_fraud_subs_checker_status
function e_fraud_subs_checker_status()
{
    $value = get_option('e_fraud_subs_checker_status', 'inactive');
    return $value;
}
function e_fraud_checker_get_fraud_data($phone_number)
{
    $api_key = get_option('e_fraud_checker_api_key');
    $domain = get_site_url();

    $response = wp_remote_post('https://server.efraudchecker.com/api/v1/shield/fraud-checker', [
        'body' => json_encode([
            'phone' => $phone_number,
            'domain' => $domain,
            'apiKey' => $api_key,
            'medium' => 'plugin',
        ]),
        'headers' => ['Content-Type' => 'application/json'],
    ]);

    if (is_wp_error($response)) {
        return ['success' => false, 'message' => 'API request failed'];
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['success']) && $data['success']) {
        return $data;
    }

    return ['success' => false, 'message' => 'No fraud data available'];
}
 // delete all transients
function efc_delete_all_transients()
{
    global $wpdb; 
     
    // delete all transients, transients name start with e_fraud_
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_e_fraud_%'");
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_e_fraud_%'");
    //_efc
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_efc_%'");
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_efc_%'");
    
    return true;
}