<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class E_Fraud_Checker_API
{

    private $api_key;
    private $domain;
    private $old_response = null;

    public function __construct()
    {
        $this->api_key = get_option('e_fraud_checker_api_key'); // Get the stored API key
        $this->domain = get_site_url(); // Get the current domain name
        $this->old_response = get_option('e_fraud_checker_subscription_data', null);
    }
    // get about us
    public static function get_about_us()
{
    $api_url = 'https://server.efraudchecker.com/api/v1/shield/get-about-us';
    
 
    $response = wp_remote_get($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        return [
            'success' => false,
            'message' => $response->get_error_message(),
        ];
    }

    $response_body = wp_remote_retrieve_body($response);
    $result = json_decode($response_body, true);

    if (isset($result['success']) && $result['success']) {
       
        return [
            'success' => true,
            'data' => $result['data'],
        ];
    }

    return [
        'success' => false,
        'message' => isset($result['message']) ? $result['message'] : 'Invalid response from API.',
    ];
}



    // Check if the API key and domain are valid
    public function validate_subscription($force= false)
    {
        $api_url = 'https://server.efraudchecker.com/api/v1/shield/check-subscription';

        $body = json_encode([
            'apiKey' => $this->api_key,
            'domain' => $this->domain,
        ]);
        $old_response_transient = get_transient('e_fraud_checker_is_valid');
        // if($old_response_transient && !$force){
        //     return 
        //     [
        //         'success' => true,
        //         'data' => $this->old_response,
        //     ];
        // }

        $response = wp_remote_post($api_url, [
            'body' => $body,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);
        if(isset($result['data']['status'])){
             update_option('e_fraud_subs_checker_status', $result['data']['status']);
        }
        if (isset($result['success']) && $result['success']) { 
            return [
                'success' => true,
                'data' => $result['data'],
            ];
        } 

        return [
            'success' => false,
            'message' => isset($result['message']) ? $result['message'] : 'Invalid response from API.',
        ];
    } 
   
      // send order data to server
      public function send_order_data($order_data)
      {
          
          $api_url = 'https://server.efraudchecker.com/api/v1/shield/fraud-checker';
  
          $data =[ 
              'apiKey' => $this->api_key,
              'domain' => $this->domain,
              'medium' => 'plugin',
          ];
          
          $data = array_merge($data, $order_data);
          $body = json_encode( $data); 
          $key = 'e_fraud_data_'.$order_data['phone'].'_'.$order_data['details']['id'];
           
          // check data
          $datas = get_transient($key);
            if ($datas) {
                return [
                    'success' => true,
                    'data' => $datas,
                ];
    
            }
  
          $response = wp_remote_post($api_url, [
              'body' => $body,
              'headers' => [
                  'Content-Type' => 'application/json',
              ],
          ]);
  
          if (is_wp_error($response)) {
              return [
                  'success' => false,
                  'message' => $response->get_error_message(),
              ];
          }
  
          $response_body = wp_remote_retrieve_body($response);
          $result = json_decode($response_body, true);
  
          if (isset($result['success']) && $result['success']) {
            set_transient($key, $result['data'], 60 * 60 * 24);
               
            set_transient('e_fraud_data_'.$order_data['phone'], $result['data'], 60 * 60 * 24);
              return [
                  'success' => true,
                  'data' => $result['data'],
              ];
          }
  
          return [
              'success' => false,
              'message' => isset($result['message']) ? $result['message'] : 'Invalid response from API.',
          ];
      }

      

    // Call the fraud-checker API with a phone number
    public function check_fraud_by_phone($phone_number, $details = null)
    {
        $api_url = 'https://server.efraudchecker.com/api/v1/shield/fraud-checker';

        $body = json_encode([
            'phone' => $phone_number,
            'domain' => $this->domain,
            'apiKey' => $this->api_key,
            'details' => $details,
            'medium' => 'plugin',
        ]);
        $datas = get_transient('e_fraud_data_'.$phone_number);
        if ($datas) {
            return [
                'success' => true,
                'data' => $datas,
            ];

        }


        $response = wp_remote_post($api_url, [
            'body' => $body,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);

        if (isset($result['success']) && $result['success']) {
            // save to cache
            set_transient('e_fraud_data_'.$phone_number, $result['data'], 60 * 60 * 24);
            return [
                'success' => true,
                'data' => $result['data'],
            ];
        }

        return [
            'success' => false,
            'message' => isset($result['message']) ? $result['message'] : 'Invalid response from API.',
        ];
    }

    // Get available packages from the API
    public static function get_available_packages() : array 
    {
        $api_url = 'https://server.efraudchecker.com/api/v1/shield/pricing';
        // wp transients
        $transient_key = 'e_fraud_available_packages';
        $transient_expiration =( 60 * 60 * 24) * 1; // 1 day
        $datas = get_transient($transient_key);
        if ($datas) {
            return [
                'success' => true,
                'data' => $datas,
            ];

        }


        $response = wp_remote_get($api_url, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message(),
            ];
        }

        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);

        if (isset($result['success']) && $result['success']) {
            // save to cache
            set_transient($transient_key, $result['data'], $transient_expiration);

            return [
                'success' => true,
                'data' => $result['data'],
            ];
        }

        return [
            'success' => false,
            'message' => isset($result['message']) ? $result['message'] : 'Invalid response from API.',
        ];
    }
}