<?php 
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class E_Fraud_Checker_Ajax
{
    public function __construct()
    {
          // ajax
        
        add_action('wp_ajax_check_fraud', [$this, 'check_fraud_order']);
        add_action('wp_ajax_e_fraud_checker_fraud_check', [$this, 'check_fraud']);
        // clear cache
        add_action('wp_ajax_e_fraud_checker_clear_cache', [$this, 'clear_cache']);
        
    }
    //clear_cache
    public function clear_cache(){
        if(efc_delete_all_transients()){
            wp_send_json_success(['message' => 'Cache cleared successfully']);
        }
    }

    public function check_fraud_order(){
        
        // validation
        if (!isset($_POST['phone'])) {
            echo 'Phone number is required';
            wp_die();
        }
        if (!isset($_POST['order_id'])) {
            echo 'Order ID is required';
            wp_die();
        }
        $order = wc_get_order($_POST['order_id']);
        if(!$order){
            echo 'Invalid Order ID';
            wp_die();
        }
        // check license status
        if (e_fraud_subs_checker_status() != 'active') {
            echo '<p class="efc-greeting-subtext expired-subtext">Your license is ' . e_fraud_subs_checker_status() . '. Please renew your license to continue using the service.</p>';
            wp_die();
        } 
        
        $phone_number = $order->get_billing_phone();
        
        //data  
        $details_data = $order->get_data();        
        // send to api
        $apiCheck = new E_Fraud_Checker_API();
        $data =[
            'phone' => $phone_number,            
            'details' => $details_data,
        ];
         

        $data = $apiCheck->send_order_data($data);
        
        if ($data['success']) {
            $totalOrders = isset($data['data']['total']['total']) ? $data['data']['total']['total'] : 0;
            $deliveredOrders = isset($data['data']['total']['delivered']) ? $data['data']['total']['delivered'] : 0;
            $returnedOrders = isset($data['data']['total']['returned']) ? $data['data']['total']['returned'] : 0;
            $successRate = isset($data['data']['total']['successRate']) ? $data['data']['total']['successRate'] : 0;

            $classSc = efc_is_fraud_by_rate($successRate) ? 'efc-progress-success' : 'efc-progress-danger';
            if($totalOrders <= 0){
                $classSc = 'efc-progress-success';
            }
            
            // UI work with the response
            echo '<span class="efc-fraud-checker-success">' . $successRate . '%</span>';

            // Progress bar with tooltip on hover
            echo '<div class="efc-progress-bar ' . ($totalOrders == 0 ? 'efc-progress-bar-none' : '') . '">
                    <div class="efc-progress ' . $classSc . '" style="width: ' . $successRate . '%;"></div>
                    <div class="tooltip">
                        Success Rate: ' . $successRate . '%<br>
                        Total Orders: ' . $totalOrders . '<br>
                        Delivered: ' . $deliveredOrders . '<br>
                        Returned: ' . $returnedOrders . '
                    </div>
                  </div>';

        } else {
            // status

            // error
            echo '<p class="efc-greeting-subtext expired-subtext">' . $data['message'] . '</p>';
        }
        wp_die();

    }

    //check_fraud
    public function check_fraud()
    {
        // validation
        if (!isset($_POST['phone_number'])) {
            echo 'Phone number is required';
            wp_die();
        }
        // var_dump(e_fraud_subs_checker_status());
        // check license status
        if (e_fraud_subs_checker_status() != 'active') {
            echo '<p class="efc-greeting-subtext expired-subtext">Your license is ' . e_fraud_subs_checker_status() . '. Please renew your license to continue using the service.</p>';
            wp_die();
        }

        $phone_number = sanitize_title($_POST['phone_number']);
        $phone_number = str_replace('+880', '0', $phone_number);

        $apiCheck = new E_Fraud_Checker_API();
        $data = $apiCheck->check_fraud_by_phone($phone_number);
        // var_dump($data);
        if ($data['success']) {
            include EFRAUDCHECKER_PATH . 'templates/fraud-check-result.php';
        } else {
            // status

            // error
            echo '<p class="efc-greeting-subtext expired-subtext">' . $data['message'] . '</p>';
        }
        wp_die();

    }

 
}