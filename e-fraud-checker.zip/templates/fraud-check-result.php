<?php
if (!defined('ABSPATH')) {
    exit;
}  

$successRate = $data['data']['total']['successRate'];
$total = $data['data']['total']['total'];
$returned = $data['data']['total']['returned'];  // Define returned
$delivered = $data['data']['total']['delivered'];  // Define delivered

$rate =  get_option('e_fraud_checker_fraud_percentage', 50);
$rate  = (int) $rate;

$alertText = $successRate >= $rate ? '<p>This customer looks genuine. You can proceed with the order.</p>' : '<p style="color: red; font-size: 14px;"> This customer may be fraudulent. Please review carefully.</p>';
$alertClass = $successRate >= $rate ? '' : 'efc-alert-danger'; // Adding a class for red background if below 50%
$alertBgColor = $successRate >= $rate ? '' : 'background-color: #fee2e2;border: 1px solid #ecbdbd;'; // Adding inline red background for below 50%

if($total == 0){
    $alertText = '<p>This customer has no order history</p>';
    $alertClass = 'efc-alert-danger';
    $alertBgColor = 'background-color: #e5e7eb;';
    ?>
    <style>
    .efc-progress-bar {
        background-color: #dddd;
    }
    </style>
<?php 
}
?>

<div class="efc-dashboard-result-content">
    <div class="efc-grid">
        <div class="efc-alert <?php echo esc_attr($alertClass); ?>" role="alert"
            style="<?php echo esc_attr($alertBgColor); ?>">
            <?php echo $alertText; ?>
        
            <?php if ($total != 0) : ?>
                <div class="efc-progress-bar-order">
                    <?php if ($returned > 0 && $delivered == 0): ?>
                        <div class="efc-progress-order" style="width: 100%; background-color: red;">
                            100% Returned
                        </div>
                    <?php else: ?>
                        <div class="efc-progress-order"
                            style="width: <?php echo esc_html($successRate); ?>%;">
                            <?php echo esc_html($successRate); ?>% Success
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="efc-card">
            <div class="efc-card-header">
                <h2>Order
                    Statistics for <?php echo esc_html($phone_number); ?> </h2>
            </div>
            <table class="efc-order-stats-table" style="width: 100%; overflow-x: auto">
                <thead>
                    <tr>
                        <th>Courier</th>
                        <th>Orders</th>
                        <th>Delivered</th>
                        <th>Returned</th>
                        <th>Success (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($data['data']['orders'])): ?>
                    <?php foreach ($data['data']['orders'] as $order): ?>
                    <tr>
                        <td><?php echo esc_html($order['title']); ?></td>
                        <td><?php echo esc_html($order['total']); ?></td>
                        <td><span class="efc-icon efc-delivered-icon"></span><?php echo esc_html($order['delivered']); ?></td>
                        <td><span class="efc-icon efc-returned-icon"></span><?php echo esc_html($order['returned']); ?></td>
                        <td>
                            <?php echo esc_html($order['successRate']); ?>%
                            <div class="efc-progress-bar <?php echo $order['total'] <= 0 ? 'efc-progress-bar-none' : '';?>">
                                <div class="efc-progress" style="width: <?php echo esc_html($order['successRate']); ?>%;"></div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <tr style="background-color: #bae6fd; font-weight: 500;">
                        <td>Total</td>
                        <td><?php echo esc_html($data['data']['total']['total']); ?></td>
                        <td><span class="efc-icon efc-delivered-icon"></span><?php echo esc_html($data['data']['total']['delivered']); ?></td>
                        <td><span class="efc-icon efc-returned-icon"></span><?php echo esc_html($data['data']['total']['returned']); ?></td>
                        <td>
                            <?php echo esc_html($data['data']['total']['successRate']); ?>%
                            <div class="efc-progress-bar">
                                <div class="efc-progress" style="width:  <?php echo esc_html($data['data']['total']['successRate']); ?>%;"></div>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
